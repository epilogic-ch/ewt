Le dossier "resources" contient tout ce qui est téléchargeable directement
depuis l'application via une URL (en GET). Cela concerne les images, les
styles css, les scripts javascript, etc.

Les ressources sont automatiquement déployées dans un sous-dossier
"app-resources" de l'application web ewt (par exemple dans
/tomcat/webapps/ewt/app-resources dans le cas de tomcat). Le nom de ce
sous-dossier est composé du nom de l'application (app dans l'exemple) et
du suffixe "-resources".

Pour faciliter la gestion, il est possible de placer les ressources dans
une archive zip et de demander à ewt de dézipper ces ressources
automatiquement lors du déploiement de l'application. Pour ce faire, il suffit
d'ajouter un second fichier portant le suffixe ".dounzip". Voir le
fichier /resources/bootstrap-icons-1.10.2.zip comme exemple.

Remarque:
Les xsl ne sont pas des ressources téléchargeables et n'ont pas à figurer
dans ce dossier.