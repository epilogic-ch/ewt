var arrangement = {
  // mode de fonctionnement (absolute ou relative )
  options: {
    mode: "relative"
  },

  /**
   * Référence une règle d'arrangement pour un contexte de groupe donné.
   * La fonction se charge d'adapter les entêtes de colonne de la table
   * associée au groupe en question pour y ajouter les éléments permettant
   * le tri, le filtre et la pagination.
   * @param context Contexte du groupe, sous forme de uuid
   * @param rule Arbre JSON contenant l'ensemble des règles d'arrangement du
   *             groupe. Cela inclut les règles de tri, de filtre et de
   *             pagination.
   */
  register: function(context, rule) {
    var self = this;

    // La règle a une forme du genre:
    //    {
    //        "modelName": "venteEchange",
    //        "docId": "6",
    //        "groupName": "benevoles",
    //        "sort": [
    //            {
    //                "fieldName": "idVendeur",
    //                "order": "asc"
    //            },
    //            {
    //                "fieldName": "idVenteEchange",
    //                "order": "asc"
    //            }
    //        ]
    //    }

    // on applique les adaptations d'interface
    if (rule.sort) {
      document.querySelectorAll('div.group-block[context="' + context + '"] table thead th.sortable-column[field]').forEach(function (th) {
        var fieldName = th.getAttribute("field");
        var order = undefined;

        // @todo changer pour éviter de devoir boucler
        var counter = 0;
        rule.sort.forEach(function (obj, idx) {
          if (fieldName == obj.fieldName) {
            order = obj.order;
            counter = idx + 1;
            return false;
          }
        });

        // ajout des indications de tri
        if (order) {
          if (order == "desc") {
            th.classList.add("order-desc");
          }
          else if (order == "asc") {
            th.classList.add("order-asc");
          }

          // ajout indication de position dans la règle de tri
          var orderNum = document.createElement("div");
          orderNum.classList.add("order-num");
          orderNum.appendChild(document.createTextNode(counter));
          th.appendChild(orderNum);
        }

        // ajout d'un event pour traiter le click
        th.addEventListener('click', function handleClick(event) {
          self.changeOrder(th, rule, context);
        });
      });
    }
    
    if (rule.filter) {
      document.querySelectorAll('div.group-block[context="' + context + '"] table thead tr.filter-row button.btn-update-filter').forEach(function (a) {
        a.addEventListener('click', function handleClick(event) {
          self.changeFilter(a, rule, context);
        });
      });
    }

    if (rule.pagination) {
      document.querySelectorAll('div.group-block[context="' + context + '"] table tfoot ul.pagination li a[offset]').forEach(function (a) {
        a.addEventListener('click', function handleClick(event) {
          self.changePagination(a, rule, context);
        });
      });
    }
  },

  /**
   * Modifie l'ordre d'une colonne
   * @param item Nom de champ sur lequel l'ordre de tri doit être modifié
   */
  changeOrder: function(item, rule, context) {
    var field = item.getAttribute("field");
    if (field) {
      var neworder = undefined;
      if (item.classList.contains('order-asc')) {
        neworder = 'desc';
      }
      else if (item.classList.contains('order-desc')) {
        neworder = undefined;
      }
      else {
        neworder = 'asc';
      }

      // on recherche s'il existe déjà une règle à mettre à jour
      rule.mode = this.options.mode;

      // on pourrait se contenter soit du mode "relative", soit du mode "absolute",
      // mais pour l'exemple, on montre les deux variantes
      if (this.options.mode === "relative") {
        rule.mode = 'relative';
        rule.sort = [{
            fieldName: field,
            order: (neworder == undefined ? "" : neworder)
          }];
      }
      else {
        rule.mode = 'absolute';
        var found = false;
        var res = rule.sort.forEach(function (entry, index, array) {
          if (entry.fieldName == field) {
            found = true;
            if (neworder) array[index].order = neworder;
            else array.splice(index, 1);
            return false;
          }
        });

        if (!found) {
          rule.sort[rule.sort.length] = {
            fieldName: field,
            order: neworder
          };
        }
      }

      doSubmit('arrange', rule);
    }
  },

  changeFilter: function(item, rule, context) {
    // on parcourt les règles de filtre et on adapte les valeurs et le flag "inverse"
    rule.filter.forEach(function (entry, index, array) {
      var inv = document.querySelector('div.group-block[context="' + context + '"] table thead th.filtrable-column[field="' + entry.fieldName + '"] button.btn-inverse-filter');
      entry.inverse = (inv.classList.contains('active'));

      var conditions = [];
      document.querySelectorAll('div.group-block[context="' + context + '"] table thead th.filtrable-column[field="' + entry.fieldName + '"] .filter-value').forEach(function (input, index) {
        conditions[conditions.length] = input.value;
      });
      entry.condition = conditions;
    });
    
    doSubmit('arrange', rule);
  },

  /**
   * Modifie les paramètres de pagination
   */
  changePagination: function(item, rule, context) {
    rule.mode = this.options.mode;

    if (this.options.mode === "relative") {
      var num = item.getAttribute("num");
      if (!num) num = item.getAttribute("offset");
      rule.pagination.offset = num;
    }
    else {
      var ofs = item.getAttribute("offset");
      var maxofs = Math.floor(rule.pagination.total / rule.pagination.limit);
      if (ofs === "--") {
        rule.pagination.offset = 0;
      }
      else if (ofs === "-") {
        rule.pagination.offset -= rule.pagination.limit;
        if (rule.pagination.offset < 0) rule.pagination.offset = 0;
      }
      else if (ofs === "+") {
        rule.pagination.offset += rule.pagination.limit;
        if (rule.pagination.offset > maxofs * rule.pagination.limit) rule.pagination.offset = maxofs * rule.pagination.limit;
      }
      else if (ofs === "++") {
        rule.pagination.offset = maxofs * rule.pagination.limit;
      }
      else {
        rule.pagination.offset = Number(ofs);
      }
    }

    doSubmit('arrange', rule);
  }
}