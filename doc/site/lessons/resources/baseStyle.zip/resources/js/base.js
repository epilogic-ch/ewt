var isSubmitting = false; // flag permettant de court-circuiter le message afficher à l'unload
var formHasChanged = false;
var sidebar = undefined;
var toastSessionTTL = undefined;
var sessionCheckIntervalID = undefined;
var modalDialogs = {};

$(document).ready(function() {
  $('#search-filter').on('keypress', function (e) {
    // déclenchement de la recherche lors du "enter" dans le champ
    if (e.key == "Enter") {
      e.preventDefault;
      doSearch();
    }
  });

  $('.content-toggler').on('click', function (e) {
    var btn = e.target;
    var content = $(btn).parent().find('.content');
    var icon = $(btn).find('.bi').first();
    if (content) {
      if (content.attr('data-state') == 'open') {
        content.hide().attr('data-state', 'closed');
        $(icon).removeClass('bi-chevron-up').addClass('bi-chevron-down');
      } else {
        content.show().attr('data-state', 'open');
        $(icon).removeClass('bi-chevron-down').addClass('bi-chevron-up');
      }
    }
  });

  if (document.getElementById('toast-session-ttl')) {
    sessionCheckIntervalID = setInterval(function() {
      var ttl = appSettings['sessionEOL'] - Date.now();

      if (ttl > 0) {
        $('#session-ttl').text(millisToMinutesAndSeconds(ttl));
        if (ttl <= appSettings['sessionTTLWarnLimit']) {
          if (toastSessionTTL == undefined) {
            toastSessionTTL = bootstrap.Toast.getOrCreateInstance(document.getElementById('toast-session-ttl'));
            toastSessionTTL.show();
          }
        }
      } else {
        clearInterval(sessionCheckIntervalID);
        sessionCheckIntervalID = undefined;

        // blocage de la session
        toastSessionTTL.hide();

        var myModal = new bootstrap.Modal(document.getElementById('modal-session-off'), {});
        myModal.show();
      }
    }, 1000);
  }

  // détection fermeture du navigateur
  $(document).on('change', $('.ewt-datafield'), function(e) {
    formHasChanged = true;
  });
  window.onbeforeunload = confirmUnload;
  document.querySelector('form').onsubmit = function() {
    isSubmitting = true;
  }

  var el = document.querySelector('.sidebar-collapsable');
  if (el) {
    var breakpoint = findBreakpoint();
    if (breakpoint == 'xs' || breakpoint == 'sm' || breakpoint == 'md') {
      el.classList.remove('sidebar-collapsable');
      el.classList.add('sidebar-collapsed');
      document.getElementById('session_sidebar-collapsed').value = 'true';
    } else {
      document.getElementById('session_sidebar-collapsed').value = 'false';
    }
  }

  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
});

// effectue un submit standard sur /web
function doSubmit(action, params, context, supplement) {
  let command = {};
  command.action = action;
  command.params = params;
  command.supplement = supplement;

  $('#ewt_command').val(JSON.stringify(command));
  $('#ewt_context').val(context);
  //console.log($('#ewt_command').val());
  $('#form').submit();
}

// effectue un submit sur /web via XMLHttpRequest
function doAjax(action, params, context, options) {
  let command = {};
  command.action = action;
  command.params = params;

  $('#ewt_command').val(JSON.stringify(command));
  $('#ewt_context').val(context);
  //console.log($('#ewt_command').val());
  //console.log($('.ewt-hidden-field').serialize());

  options = $.extend({
    method: 'POST',
    url: window.location.pathname,
    asynchronous: true,
    body: $('.ewt-hidden-field').serialize(),
    headers: {'Content-Type' : 'application/x-www-form-urlencoded; charset=utf-8'},
    timeout: 2500,  // on met un timeout histoire de ne pas générer d'erreur 502 dans le cas de traitements longs
    onLoad: undefined,
    onLoadStart: undefined,
    onLoadEnd: undefined,
    onError: undefined,
    onAbort: undefined,
    onTimeout: undefined,
    onProgress: undefined,
    onReadyStateChange: undefined,
    withCredentials: undefined,
    responseType: undefined
  }, (options || {}));

  var xhr = new XMLHttpRequest();
  if (options.withCredentials != undefined) xhr.withCredentials = options.withCredentials;
  if (options.responseType != undefined) xhr.responseType = options.responseType;
  xhr.open(options.method, options.url, options.asynchronous);

  if (options.headers) {
    $.each(options.headers, function(key, val) {
      xhr.setRequestHeader(key, val);
    });
  }

  if (options.onLoad) xhr.onload = function(e) { options.onLoad(xhr, e) };
  if (options.onLoadStart) xhr.onloadstart = function(e) { options.onLoadStart(xhr, e) };
  if (options.onLoadEnd) xhr.onloadend = function(e) { options.onLoadEnd(xhr, e) };
  if (options.onError) xhr.onerror = function(e) { options.onError(xhr, e) };
  if (options.onAbort) xhr.onabort = function(e) { options.onAbor(xhr, e) };
  if (options.onTimeout && options.timeout > 0) {
    xhr.timeout = options.timeout;
    xhr.ontimeout = function(e) { options.onTimeout(xhr, e) };
  }
  if (options.onProgress) xhr.onprogress = function(e) { options.onProgress(xhr, e) };
  if (options.onReadyStateChange) xhr.onreadystatechange = function(e) { options.onReadyStateChange(xhr, e) };

  xhr.send(options.body);
}

// effectue un appel REST (servlet /rest) via XMLHttpRequest
function doRest(options, context) {
  var defaultHeaders = { "x-ewt-sessionid": $('#ewt_sessionid').val() };

  if (context) {
    defaultHeaders = $.extend(defaultHeaders, { "x-ewt-context": context });
  }

  options = $.extend({
    method: 'POST',
    url: window.location.pathname,
    asynchronous: true,
    body: undefined,
    headers: defaultHeaders,
    timeout: 2500,  // on met un timeout histoire de ne pas générer d'erreur 502 dans le cas de traitements longs
    onLoad: undefined,
    onLoadStart: undefined,
    onLoadEnd: undefined,
    onError: undefined,
    onAbort: undefined,
    onTimeout: undefined,
    onProgress: undefined,
    onReadyStateChange: undefined,
    withCredentials: undefined,
    responseType: undefined
  }, (options || {}));

  var xhr = new XMLHttpRequest();
  if (options.withCredentials != undefined) xhr.withCredentials = options.withCredentials;
  if (options.responseType != undefined) xhr.responseType = options.responseType;
  xhr.open(options.method, options.url, options.asynchronous);

  if (options.headers) {
    $.each(options.headers, function(key, val) {
      xhr.setRequestHeader(key, val);
    });
  }

  if (options.onLoad) xhr.onload = function(e) { options.onLoad(xhr, e) };
  if (options.onLoadStart) xhr.onloadstart = function(e) { options.onLoadStart(xhr, e) };
  if (options.onLoadEnd) xhr.onloadend = function(e) { options.onLoadEnd(xhr, e) };
  if (options.onError) xhr.onerror = function(e) { options.onError(xhr, e) };
  if (options.onAbort) xhr.onabort = function(e) { options.onAbor(xhr, e) };
  if (options.onTimeout && options.timeout > 0) {
    xhr.timeout = options.timeout;
    xhr.ontimeout = function(e) { options.onTimeout(xhr, e) };
  }
  if (options.onProgress) xhr.onprogress = function(e) { options.onProgress(xhr, e) };
  if (options.onReadyStateChange) xhr.onreadystatechange = function(e) { options.onReadyStateChange(xhr, e) };

  xhr.send(options.body);
}

function doGetData(options, context) {
 options = $.extend({
    method: 'GET',
    url: appSettings['contextPath']+'/data/'+appSettings['application'],
    withCredentials: true,
    responseType: 'blob',
    onLoad: function(xhr, e) {
      if (xhr.status === 200) {
        doPromptForDownload(xhr, e, this);
      }
    }
  }, (options || {}));

  doRest(options, context);
}

function doPromptForDownload(xhr, e, options) {
  // basé sur https://stackoverflow.com/a/23797348/1585114
  // on pourrait aussi l'implémenter selon https://stackoverflow.com/a/27563953
  var blob = xhr.response;
  var filename = "";
  var disposition = xhr.getResponseHeader('Content-Disposition');
  if (disposition && disposition.indexOf('attachment') !== -1) {
      var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
      var matches = filenameRegex.exec(disposition);
      if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
  }

  if (typeof window.navigator.msSaveBlob !== 'undefined') {
      // IE workaround for "HTML7007: One or more blob URLs were revoked by closing the blob
      // for which they were created. These URLs will no longer resolve as the data backing the URL has been freed."
      window.navigator.msSaveBlob(blob, filename);
  } else {
      var URL = window.URL || window.webkitURL;
      var downloadUrl = URL.createObjectURL(blob);

      if (filename) {
          // use HTML5 a[download] attribute to specify filename
          var a = document.createElement("a");
          // safari doesn't support this yet
          if (typeof a.download === 'undefined') {
              window.location.href = downloadUrl;
          } else {
              a.href = downloadUrl;
              a.download = filename;
              document.body.appendChild(a);
              a.click();
          }
      } else {
          window.location.href = downloadUrl;
      }

      setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 100); // cleanup
  }
}

function doSearch() {
  doSubmit('script', { name: 'search', parameters: { filter: $('#search-filter').val() } });
}

function changeCategory(category) {
  $('#session_current-categorie').val(category);
  doSubmit('dummy');
}

/**
 * Création d'une fenêtre modal
 * Paramètres:
 *   settings : options de la fenêtre
 *                id : identifiant de la fenêtre
 *                title : titre
 *                size : taille ('sm', 'lg', 'xl', 'fullscreen', 'fullscreen-sm-down', 'fullscreen-md-down', 'fullscreen-lg-down', 'fullscreen-xl-down', 'fullscreen-xxl-down')
 *                body : html de remplissage du corps de la fenêtre
 *                footer : html du footer ou 'default' pour utiliser le footer par défaut avec un bouton "Fermer"
 *                closeX : html du bouton de fermeture situé dans le coin supérieur droit, ou 'default' pour utiliser la croix par défaut
 *                onOpen : fonction de callback à invoker à l'ouverture de la fenêtre modale
 *                onClose : fonction de callback à invoker à la fermeture de la fenêtre modale
 *                ajaxScript : paramètres de script à évaluer pour obtenir le contenu de la fenêtre modal
 */
function doCreateModal(settings) {
  settings = $.extend({
    id: undefined,
    title: "",
    size: undefined,
    body: '<div class="spinner-border" role="status"><span class="visually-hidden">Chargement en cours...</span></div>',
    footer: "default",
    closeX: "default",
    onOpen : undefined,
    onClose : undefined,
    ajaxScript: undefined
  }, (settings || {}));

  if (settings.footer == 'default') {
    settings.footer = '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>';
  } else if (settings.footer == undefined) {
    settings.footer = "";
  }

  if (settings.closeX == 'default') {
    settings.closeX = '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
  } else if (settings.closeX == undefined) {
    settings.closeX = "";
  }

  if (settings.size != undefined && !settings.size.startsWith('-')) settings.size = '-' + settings.size;

  var dlg = '<div class="modal fade" id="'+settings.id+'" data-bs-backdrop="static" tabindex="-1" aria-labelledby="'+settings.id+'-Label" aria-hidden="true">' +
              '<div class="modal-dialog modal'+settings.size+'">' +
                '<div class="modal-content">' +
                  '<div class="modal-header">'+
                    '<h1 class="modal-title fs-5" id="'+settings.id+'-Label">'+settings.title+'</h1>'+
                    settings.closeX +
                  '</div>'+
                  '<div class="modal-body" id="' + settings.id + '-body"></div>';

  if (settings.footer) {
    dlg += '<div class="modal-footer">'+settings.footer+'</div>';
  }
  dlg += '</div></div></div>';

  $(document.body).append($(dlg));

  if (typeof settings.body == "object") {
    // on insère un élément à l'endroit de l'élément que l'on va reprendre dans la fenêtre modal
    $('<div id="' + settings.id + '-orig"/>').insertAfter(settings.body);
    settings.body.detach().appendTo('#' + settings.id + '-body').show();
  } else {
    $('#' + settings.id + '-body').html(settings.body);
  }

  //$('#'+settings.id+' .modal-content').resizable({ minHeight: 100, minWidth: 100 });
  //$('#'+settings.id+' .modal-dialog').draggable();

  const data = {
    singleton: (typeof settings.body == "object"), // true si la fenêtre reprend un objet existant (et qui doit exister après la fermeture)
    settings: settings
  };

  modalDialogs[settings.id] = data;

  $('#'+settings.id)
    .on('show.bs.modal', function () {
      var id = $(this).attr('id');
      $('#' + id + ' .modal-body').css({
        'max-height': '100%'
      });
    })
    .on('hidden.bs.modal', function() {
      var id = $(this).attr('id');
      if (typeof modalDialogs[id].settings.onClose == "function") {
        modalDialogs[id].settings.onClose();
      }
      if (modalDialogs[id].singleton) {
        $('#' + id + '-orig').replaceWith($('#' + id + '-body').children().hide().detach());
      }

      delete modalDialogs[id];

      $('#'+id).removeData('bs.modal');
      $('#'+id).get(0).remove();
      $('#'+id).remove();
    });

  if (typeof modalDialogs[settings.id].settings.onOpen == "function") {
    $('#'+settings.id).on('shown.bs.modal', function() {
      var id = $(this).attr('id');
      modalDialogs[id].settings.onOpen();
    });
  }

  modalDialogs[settings.id].modal = new bootstrap.Modal(document.getElementById(settings.id), {});
  modalDialogs[settings.id].modal.show();

  if (settings.ajaxScript) {
    doAjax('script',
       settings.ajaxScript,
       undefined,
       { onLoad: function(xhr, e) {
          $('#'+settings.id+' .modal-body').html(xhr.response);
        }
     });
  }

  return modalDialogs[settings.id].modal;
}

function doCloseModal(id) {
  if (modalDialogs[id] != undefined) {
    modalDialogs[id].modal.hide();
  }
}

function confirmUnload(e) {
  if (!isSubmitting && formHasChanged && appSettings['numDocs'] > 0) {
    var message = "Vos modifications n'ont pas été sauvées. Voulez-vous vraiment fermer la fenêtre ?";
    e = e || window.event;
    if (e) {
      e.returnValue = message;
    }
    return message;
  }
}

/**
 * One of xs, sm, md, lg, xl. xxl
 * @returns {String}
 */
function findBreakpoint() {
  var cstyles = window.getComputedStyle(document.documentElement);
  var width = $(window).width();

  if (width < parseInt(cstyles.getPropertyValue("--breakpoint-sm"), 10)) return 'xs';
  else if (width < parseInt(cstyles.getPropertyValue("--breakpoint-md"), 10)) return 'sm';
  else if (width < parseInt(cstyles.getPropertyValue("--breakpoint-lg"), 10)) return 'md';
  else if (width < parseInt(cstyles.getPropertyValue("--breakpoint-xl"), 10)) return 'lg';
  else if (width < parseInt(cstyles.getPropertyValue("--breakpoint-xxl"), 10)) return 'xl';
  else return 'xxl';
}

// gestion du theme couleur (light / dark)
function setColorScheme(theme) {
  if (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    appSettings.colorScheme = 'dark';
  } else {
    appSettings.colorScheme = theme;
  }

  document.documentElement.setAttribute('data-bs-theme', appSettings.colorScheme);
  document.getElementById('colorscheme').value = appSettings.colorScheme;
}