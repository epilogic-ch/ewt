/*
 * Gestionnaire de sidebar
 * Auteur: epilogic sàrl, 2022
 *
 * Principe:
 * La librairie part du principe que le code html a la forme suivante:
 *
 *   <div id="controler">
 *     <div id="sidebar">...</div>
 *     <div id="content">...</div>
 *   <div>
 *
 * Elle ajoute une classe à l'élément #controler lorsque la sidebar
 * doit être réduite. À l'inverse, elle retire cette classe à l'élément
 * #controler lorsque la sidebar doit être élargie. Les paramètres de
 * dimensionnement de la sidebar sont à définir au niveau des feuilles
 * de style CSS.
 */
 
function Sidebar(options) {
  this.options = $.extend({
    controler: undefined,
    classname: undefined,
    onChange: undefined
  }, (options || {}));
}

Sidebar.prototype.enlarge = function() {
  $(this.options.controler).removeClass(this.options.classname);

  this.fireChange();
}

Sidebar.prototype.collapse = function() {
  $(this.options.controler).addClass(this.options.classname);

  this.fireChange();
}

Sidebar.prototype.toggle = function() {
  if (this.isCollapsed()) {
    this.enlarge();
  } else {
    this.collapse();
  }
}

Sidebar.prototype.showSubmenu = function(submenu, evt) {
  evt.stopPropagation();

  this.animateOpen($(".sidebar-submenu[ref='"+submenu+"']"));
}

Sidebar.prototype.hideSubmenu = function(submenu, evt) {
  evt.stopPropagation();

  this.animateHide($(".sidebar-submenu[ref='"+submenu+"']"));
}

// Fonctions internes

Sidebar.prototype.fireChange = function() {
  if (typeof this.options.onChange === 'function') {
    this.options.onChange(this.isCollapsed());
  }
}

Sidebar.prototype.isCollapsed = function() {
  return $(this.options.controler).hasClass(this.options.classname);
}

Sidebar.prototype.animateOpen = function(obj) {
  obj.show().animate({
    left: 0
  }, obj.width());
}

Sidebar.prototype.animateHide = function(obj) {
  obj.animate({
    left: -obj.width()
  }, 100, function() {
    obj.hide();
  });
}